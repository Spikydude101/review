// Review of Grade 10 CS
// Before we tackle some new materials, let's make sure we are on the same page and review some important concepts from last year:

// Console output
// https://www.w3schools.com/jsref/met_console_log.asp
console.log('hello world');
// Variables:
// https://www.w3schools.com/js/js_variables.asp
let myVariable = 72;
var my_other_variable = 'Jack Frost';
// String concatenation
// https://www.youtube.com/watch?v=7ktrTvRhhqk
let sentence = my_other_variable + ' is ' +  myVariable + ' years old.';
console.log(sentence);
// Arithmetic Operators including Modulus
// https://www.w3schools.com/js/js_arithmetic.asp
let remainder = 100 % 19;
console.log(remainder);
// Rounding values
// https://www.w3schools.com/jsref/jsref_tofixed.asp
let division = 100 / 19;
console.log(division);
division = division.toFixed(2);
console.log(division);
// If, else, else if
// https://www.w3schools.com/js/js_if_else.asp
if (myVariable == 71){
  console.log('blurb');
}else if (remainder == 5){
  console.log('flurb');
}else {
  console.log('zlurb');
}
// Prompting the user:
// https://www.w3schools.com/jsref/met_win_prompt.asp

// Loops
// https://www.w3schools.com/js/js_loop_for.asp
for(let i = 3; i < 100; i = i + 7){
  console.log(i);
}
// Break and Continue
// https://www.w3schools.com/js/js_break.asp



// Question 1
// Write code that asks the user for a number and outputs a number that is 5 more than the number they selected.  E.g. If they enter 2, you should output 7.

//asks user for number

// let option1 = +prompt('enter a number');



//adds 5 to inputed number

// let option2 = option1 + 5;

//shows what new number is 

// console.log(option2);

// Question 2
// Write code that asks the user for the radius of a circle, then output the area of that circle. Use Math.PI instead of 3.14 for your calculation. 

// ask for radius of circle

// let rad = +prompt("enter circle radius");

//calculates area of circle

// let area = Math.PI * rad * rad;

//outputs area

// console.log("The area of a circle with radius " + rad + " is " + area.toFixed(2) + ".");

// Question 3
// Write code that prompts for 3 inputs: an animal, a color, and an exclamation. Then form any sentence that uses those inputs.  E.g. ‘The red chicken shouted “HIYA!!”’


// let pet = prompt('Choose any animal');

// console.log(pet);

// let crayon_color = prompt('choose a color');

// console.log(crayon_color);

// let word_lingo = prompt('choose an exclamation');

// console.log(word_lingo);

// let mix_and_match = "a " +  crayon_color   + " " +  pet  +  " exclaimed " + word_lingo;

// console.log(mix_and_match);

// Question 4
// Write code that asks the user for a number, then output a statement saying that number is positive or negative. E.g. If the user types -4, your output should say “The number -4 is negative”.

// can_you_count = +prompt('enter a number please');


// if(can_you_count < 0 ){
//   let writing = "The " +  "number " +  can_you_count + " is " + " a " + " - number ";

//   console.log(writing);

// }else if(can_you_count > 0){
//   let writing2 = "The " + " number " +  can_you_count +  " is " +
//   " a " + " + number ";

//   console.log(writing2);

// }else if(can_you_count == 0){

//   let pos_or_neg = "Zero " +  " is not " + " a - or a + number ";

//   console.log(pos_or_neg);
// }

// Question 5
// Add an if statement inside the loop so that only the multiple of 4 are printed from 0 to 100.

// for(let i = 0; i <= 100; i++){
//   if(i % 4 == 0){
//     console.log(i);
//   }
// }

// Pro-tip: Highlight multiple lines then presse CTRL-/  to uncomment or comment multiple lines at once



// Question 6
// Write code that asks the user for two numbers. Then, output the remainder if you were to divide those numbers.  E.g. If the user selects the numbers 10 and 3, your code should say “10 divided by 3 gives a remainder of 1”.

// let num1 = +prompt("Enter you first number");


// let num2 = +prompt("enter your second number");


// let remaining = num1 % num2;


// let left = num1 + " divided by " + num2 + " gives a remainder of " + remaining;

// console.log(left);

// Question 7
// Write code that asks the user for a colour on the flag of Sudan. If they type in one of the correct colours, output “CORRECT". Otherwise output “That colour is not on the Sudanese flag".

// let color_chosen = prompt("Enter a color that is on the Sudan flag");


// if(color_chosen == "green" || color_chosen == "red" || color_chosen == "white" || color_chosen == "black"){

//   let correct = "Correct";

//   console.log(correct);

// }else {
//   let incorrect = "That color is not on the sudan flag";

//   console.log(incorrect);
// }

// Question 8
// Complete the for loop inner bracket below so that only the following is output: 
// 5
// 10
// 15
// 20
// 25
// 30

// for (let i = 5; i <= 30; i = i + 5) {

//   console.log(i);
// }

// Question 9
// Prompt the user for a sentence, but they only submit one word at a time. The user indicates they are done typing words when they type nothing at all before hitting the enter key. When this happens, output the sentence.

let sentence = ''; 
while (true) {
  let word = prompt('Enter a word');

  // Add code below
  if(word == '') break;

  sentence += word + ' ';




}//end of loop



sentence += '.';

console.log(sentence);